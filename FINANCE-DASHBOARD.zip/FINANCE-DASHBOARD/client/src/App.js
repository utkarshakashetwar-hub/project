function App() {
  return (
    <div>
      <h1>Finance Dashboard</h1>
    </div>
  );
}

export default App;
