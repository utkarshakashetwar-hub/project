const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  res.send("Expense Route");
});

module.exports = router;
